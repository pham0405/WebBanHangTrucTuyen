<!-- Page Heading -->

<?php $__env->startSection('contentsAdm'); ?>
    <h1 class="h3 mb-2 text-gray-800">Danh Sách Sản Phẩm</h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <a href="<?php echo e(route('addProd')); ?>"><button class="btn text-gray-100 bg-gradient-primary">Thêm Sản Phẩm</button></a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Sản Phẩm</th>
                            <th>Ảnh</th>
                            <th>Giá</th>
                            <th>Số lượng</th>
                            <th>Mô tả</th>
                            <th>Lượt xem</th>
                            <th>Chỉnh Sửa</th>
                            <th>Xóa</th>
                        </tr>
                    </thead>

                    <tfoot>
                        <tr>
                            <th>#</th>
                            <th>Sản Phẩm</th>
                            <th>Ảnh</th>
                            <th>Giá</th>
                            <th>Số lượng</th>
                            <th>Mô tả</th>
                            <th>Lượt xem</th>
                            <th>Chỉnh Sửa</th>
                            <th>Xóa</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($product->id); ?></td>
                                <td><?php echo e($product->name); ?></td>
                                <td><img src="<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>" width="100"></td>
                                <td><?php echo e($product->price); ?></td>
                                <td><?php echo e($product->quantity); ?></td>
                                <td><?php echo e($product->description); ?></td>
                                <td><?php echo e($product->view); ?></td>

                                <td style="text-align: center;"><a href="#" class="nav-link"><i
                                            class="fa-solid fa-pen-to-square"></i></a></td>
                                
                                        <td>
    <a href="<?php echo e(route('products.destroy', $product->id)); ?>"
       onclick="event.preventDefault(); if(confirm('Bạn có chắc chắn muốn xóa?')) document.getElementById('delete-form-<?php echo e($product->id); ?>').submit();">
       <i class="fa-regular fa-circle-xmark"></i>
    </a>
    <form id="delete-form-<?php echo e($product->id); ?>" action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST" style="display: none;">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
    </form>
</td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/x/Documents/GitHub/WebBanHangTrucTuyen/example-app/resources/views/layout/admin/products.blade.php ENDPATH**/ ?>