
<?php /**PATH /Users/x/Documents/GitHub/WebBanHangTrucTuyen/example-app/resources/views/welcome.blade.php ENDPATH**/ ?>