<?php $__env->startSection('contentsAdm'); ?>
<!-- Page Heading -->
<h1 class="h3 mb-2 text-gray-800">Quản Lý Bình Luận</h1>

<!-- DataTales Example -->
<div class="card shadow mb-4">

    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Sản Phẩm</th>
                        <th>Bình Luận Mới Nhất</th>
                        <th>Số Bình Luận</th>
                        <th>Xem Chi Tiết</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>#</th>
                        <th>Sản Phẩm</th>
                        <th>Bình Luận Mới Nhất</th>
                        <th>Số Bình Luận</th>
                        <th>Xem Chi Tiết</th>
                    </tr>
                </tfoot>
                <tbody>

                    
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/x/Documents/GitHub/WebBanHangTrucTuyen/example-app/resources/views/layout/admin/comment.blade.php ENDPATH**/ ?>