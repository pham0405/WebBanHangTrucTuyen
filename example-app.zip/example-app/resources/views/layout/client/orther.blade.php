@extends('layout.master')
@section('contents')
@title('Khác')
<div>
    
</div>
@endsection