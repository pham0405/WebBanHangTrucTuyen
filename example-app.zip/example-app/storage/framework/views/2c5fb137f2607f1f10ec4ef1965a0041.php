<?php $__env->startSection('contents'); ?>
<?php view()->share('title', 'Khác'); ?>
<div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/x/Documents/GitHub/WebBanHangTrucTuyen/example-app/resources/views/layout/client/orther.blade.php ENDPATH**/ ?>