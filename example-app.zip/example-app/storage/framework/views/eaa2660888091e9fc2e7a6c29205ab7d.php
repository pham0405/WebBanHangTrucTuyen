<footer class="sticky-footer bg-white">
  <div class="container my-auto">
      <div class="copyright text-center my-auto">
          <span>LNP Store &copy; Cửa Hàng Điện Thoại Uy Tín - Chất Lượng</span>
      </div>
  </div>
</footer><?php /**PATH /Users/x/Documents/GitHub/WebBanHangTrucTuyen/example-app/resources/views/components/admin/footer.blade.php ENDPATH**/ ?>