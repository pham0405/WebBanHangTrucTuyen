@extends('layout.master')
@section('contents')
@title('Bài viết')
<div>
    <h1>Danh sách bài viết </h1>
    
</div>
@endsection
