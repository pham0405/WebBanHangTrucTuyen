@extends('layout.master')

@section('title' , 'Homepage')
@section('content')    
@endsection
@push('style')
    
@endpush

@push('script')
    
@endpush




