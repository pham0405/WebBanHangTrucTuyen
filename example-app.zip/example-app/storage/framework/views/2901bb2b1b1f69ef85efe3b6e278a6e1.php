<?php $__env->startSection('contents'); ?>
<?php view()->share('title', 'Bài viết'); ?>
<div>
    <h1>Danh sách bài viết </h1>
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/x/Documents/GitHub/WebBanHangTrucTuyen/example-app/resources/views/layout/client/blog.blade.php ENDPATH**/ ?>